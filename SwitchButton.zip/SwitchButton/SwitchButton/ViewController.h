//
//  ViewController.h
//  SwitchButton
//
//  Created by A on 21/03/17.
//  Copyright (c) 2017 mine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property(nonatomic,weak)IBOutlet UISwitch *switch1;
@property(nonatomic,weak)IBOutlet UIButton *button;


@end

